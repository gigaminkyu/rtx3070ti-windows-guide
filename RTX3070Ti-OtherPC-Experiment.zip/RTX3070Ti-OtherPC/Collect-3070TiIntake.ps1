# Windows PowerShell 5.1. Public hardware intake, NOT an unlock tool.
# Only the JSON report is written, beneath this script's own output directory.
# No network, downloads, firmware access, GPU reset, boot or security changes.
# Dot-sourcing imports the functions without collecting or writing anything.

function Get-3070TiIntakeAssessment {
    param([Parameter(Mandatory = $true)] [object] $Inventory)
    $missing = New-Object 'System.Collections.Generic.List[string]'
    $differences = New-Object 'System.Collections.Generic.List[string]'
    $notes = New-Object 'System.Collections.Generic.List[string]'
    foreach ($failure in @($Inventory.QueryFailures)) {
        if ($failure) { $missing.Add('QUERY_UNAVAILABLE: ' + $failure) }
    }
    $gpus = @($Inventory.Gpus | Where-Object { $null -ne $_ })
    $targets = @($gpus | Where-Object {
        $_.VendorId -eq '10DE' -and ($_.DeviceId -eq '2482' -or $_.Name -match '\bRTX\s*3070\s*Ti\b')
    })
    $gpuQueryComplete = @($Inventory.QueryFailures) -notcontains 'GPU'
    if ($null -eq $Inventory.PSObject.Properties['Gpus']) {
        $gpuQueryComplete = $false
        $missing.Add('FIELD_UNAVAILABLE: Gpus')
    }
    foreach ($gpu in $gpus) {
        foreach ($field in @('Name', 'VendorId', 'DeviceId', 'SubsystemId', 'DriverVersion')) {
            if ([string]::IsNullOrWhiteSpace([string]$gpu.$field)) { $missing.Add('GPU_FIELD_UNAVAILABLE: ' + $field) }
        }
    }
    $knownGpuIdentities = @($gpus | Where-Object {
        -not [string]::IsNullOrWhiteSpace([string]$_.VendorId) -and
        -not [string]::IsNullOrWhiteSpace([string]$_.DeviceId) -and
        -not [string]::IsNullOrWhiteSpace([string]$_.Name)
    }).Count -eq $gpus.Count

    $fields = [ordered]@{
        BoardManufacturer = $Inventory.Board.Manufacturer
        BoardModel = $Inventory.Board.Model
        BiosVersion = $Inventory.Bios.Version
        CpuName = $Inventory.Cpu.Name
        CpuArchitecture = $Inventory.Cpu.Architecture
        OsCaption = $Inventory.Os.Caption
        OsVersion = $Inventory.Os.Version
        OsBuild = $Inventory.Os.Build
        OsArchitecture = $Inventory.Os.Architecture
    }
    foreach ($name in $fields.Keys) {
        if ([string]::IsNullOrWhiteSpace([string]$fields[$name])) { $missing.Add('FIELD_UNAVAILABLE: ' + $name) }
    }
    if ($Inventory.Board.Model -and $Inventory.Board.Model.Trim() -ne 'TUF GAMING B660M-E D4') { $differences.Add('BOARD_MODEL_DIFFERS') }
    if ($Inventory.Board.Manufacturer -and $Inventory.Board.Manufacturer.Trim() -ne 'ASUSTeK COMPUTER INC.') { $differences.Add('BOARD_MANUFACTURER_DIFFERS') }
    if ($Inventory.Bios.Version -and $Inventory.Bios.Version.Trim() -ne '4003') { $differences.Add('BIOS_VERSION_DIFFERS') }
    if ($Inventory.Cpu.Name -and $Inventory.Cpu.Name -notmatch '\bi7-12700F\b') { $differences.Add('CPU_DIFFERS') }
    if ($null -ne $Inventory.Cpu.Architecture -and $Inventory.Cpu.Architecture -ne 9) { $differences.Add('CPU_ARCHITECTURE_DIFFERS_FROM_X64') }
    if ($Inventory.Os.Caption -and $Inventory.Os.Caption -notmatch 'Windows 11 Pro$') { $differences.Add('OS_EDITION_DIFFERS') }
    if ($Inventory.Os.Build -and [string]$Inventory.Os.Build -ne '22000') { $differences.Add('OS_BUILD_DIFFERS') }
    if ($Inventory.Os.Architecture -and $Inventory.Os.Architecture -notmatch '64') { $differences.Add('OS_ARCHITECTURE_DIFFERS') }
    if ($gpuQueryComplete -and $gpus.Count -ne 1) { $differences.Add('DISPLAY_ADAPTER_COUNT_DIFFERS_FROM_ONE') }
    foreach ($gpu in $targets) {
        if ($gpu.DeviceId -and $gpu.DeviceId -ne '2482') { $differences.Add('GPU_DEVICE_DIFFERS_FROM_REFERENCE_DESKTOP_CARD') }
        if ($gpu.SubsystemId -and $gpu.SubsystemId -ne '50521462') { $differences.Add('GPU_SUBSYSTEM_DIFFERS') }
        if ($gpu.DriverVersion -and $gpu.DriverVersion -ne '32.0.16.1692') { $differences.Add('DRIVER_DIFFERS_FROM_616_92') }
    }
    if ($Inventory.Security.SecureBoot -notin @('Enabled', 'Disabled')) { $missing.Add('SECURE_BOOT_UNKNOWN') }
    elseif ($Inventory.Security.SecureBoot -eq 'Enabled') { $notes.Add('Secure Boot is enabled. This tool does not change it.') }
    $volume = $Inventory.Security.OsVolume
    if ($volume.VolumeStatus -notin @('FullyDecrypted', 'FullyEncrypted', 'EncryptionInProgress', 'DecryptionInProgress', 'EncryptionPaused', 'DecryptionPaused')) { $missing.Add('OS_VOLUME_CONVERSION_STATUS_UNKNOWN') }
    elseif ($volume.VolumeStatus -ne 'FullyDecrypted') { $notes.Add('The OS volume is not fully decrypted. Protection Off alone does not mean decrypted. No encryption setting was changed.') }
    if ($volume.ProtectionStatus -notin @('On', 'Off')) { $missing.Add('OS_VOLUME_PROTECTION_STATUS_UNKNOWN') }
    if ($null -eq $volume.EncryptionPercentage) { $missing.Add('OS_VOLUME_ENCRYPTION_PERCENTAGE_UNKNOWN') }

    # A known different GPU remains identifiable even without elevated queries.
    if ($gpuQueryComplete -and $knownGpuIdentities -and $targets.Count -eq 0) { $status = 'NOT_RTX3070TI' }
    elseif ($missing.Count -gt 0 -or -not $gpuQueryComplete) { $status = 'INCOMPLETE' }
    elseif ($differences.Count -gt 0) { $status = 'RTX3070TI_FOUND_UNVALIDATED' }
    else { $status = 'REFERENCE_FIELDS_MATCH_NOT_VALIDATED' }
    $notes.Add('These labels describe this inventory and one public reference machine. A different machine is not proof that unlocking is impossible.')
    $notes.Add('An RTX 3070 Ti on another machine requires review of the experimental automatic-profile path and validation on that machine; a separate hardcoded motherboard profile is not presumed necessary.')
    $notes.Add('Reference fields matching is not firmware validation or permission to run an unlock. PROM, PCI/BAR layout, EFI ownership, cleanup and actual driver behavior remain unchecked.')
    $notes.Add('WMI AdapterRAM is a 32-bit reported value and may be truncated. It does not establish actual VRAM capacity.')
    [pscustomobject][ordered]@{
        Status = $status
        ReferenceDifferences = @($differences.ToArray() | Select-Object -Unique)
        MissingInformation = @($missing.ToArray() | Select-Object -Unique)
        Notes = $notes.ToArray()
    }
}

function Get-3070TiIntakeInventory {
    $failures = New-Object 'System.Collections.Generic.List[string]'
    $data = [pscustomobject][ordered]@{
        Board = $null; Bios = $null; Cpu = $null; Os = $null; Gpus = @()
        Security = [pscustomobject]@{ SecureBoot = 'Unknown'; OsVolume = $null }
        QueryFailures = @()
    }
    try {
        $rows = @(Get-CimInstance Win32_BaseBoard -Property Manufacturer, Product -ErrorAction Stop)
        if ($rows.Count -ne 1) { throw 'Unexpected count' }
        $data.Board = [pscustomobject]@{ Manufacturer = $rows[0].Manufacturer; Model = $rows[0].Product }
    } catch { $failures.Add('Board') }
    try {
        $rows = @(Get-CimInstance Win32_BIOS -Property Manufacturer, SMBIOSBIOSVersion -ErrorAction Stop)
        if ($rows.Count -ne 1) { throw 'Unexpected count' }
        $data.Bios = [pscustomobject]@{ Manufacturer = $rows[0].Manufacturer; Version = $rows[0].SMBIOSBIOSVersion }
    } catch { $failures.Add('BIOS') }
    try {
        $rows = @(Get-CimInstance Win32_Processor -Property Name, Architecture -ErrorAction Stop)
        if ($rows.Count -ne 1) { throw 'Unexpected count' }
        $data.Cpu = [pscustomobject]@{ Name = $rows[0].Name; Architecture = $rows[0].Architecture }
    } catch { $failures.Add('CPU') }
    try {
        $rows = @(Get-CimInstance Win32_OperatingSystem -Property Caption, Version, BuildNumber, OSArchitecture -ErrorAction Stop)
        if ($rows.Count -ne 1) { throw 'Unexpected count' }
        $data.Os = [pscustomobject]@{ Caption = $rows[0].Caption; Version = $rows[0].Version; Build = $rows[0].BuildNumber; Architecture = $rows[0].OSArchitecture }
    } catch { $failures.Add('OS') }
    try {
        $data.Gpus = @(Get-CimInstance Win32_VideoController -Property Name, PNPDeviceID, DriverVersion, AdapterRAM -ErrorAction Stop | ForEach-Object {
            $adapter = $_
            $vendor = $null; $device = $null; $subsystem = $null; $bus = $null; $address = $null
            if ($adapter.PNPDeviceID -match '^PCI\\VEN_([0-9A-F]{4})&DEV_([0-9A-F]{4})&SUBSYS_([0-9A-F]{8})(?:&REV_[0-9A-F]{2})?(?:\\[^\\]*)?$') {
                $vendor = $Matches[1].ToUpperInvariant(); $device = $Matches[2].ToUpperInvariant(); $subsystem = $Matches[3].ToUpperInvariant()
                try {
                    $p = Get-PnpDeviceProperty -InstanceId $adapter.PNPDeviceID -KeyName 'DEVPKEY_Device_BusNumber' -ErrorAction Stop
                    if ($null -ne $p.Data -and $p.Data -is [ValueType]) { $bus = [uint32]$p.Data }
                } catch { }
                try {
                    $p = Get-PnpDeviceProperty -InstanceId $adapter.PNPDeviceID -KeyName 'DEVPKEY_Device_Address' -ErrorAction Stop
                    if ($null -ne $p.Data -and $p.Data -is [ValueType]) { $address = [uint32]$p.Data }
                } catch { }
            }
            $memory = $null
            if ($null -ne $adapter.AdapterRAM) { $memory = [uint64]$adapter.AdapterRAM }
            [pscustomobject]@{
                Name = $adapter.Name; VendorId = $vendor; DeviceId = $device; SubsystemId = $subsystem
                DriverVersion = $adapter.DriverVersion; WmiReportedAdapterRamBytes = $memory
                PciBusNumber = $bus; PciAddressRaw = $address
            }
        })
    } catch { $data.Gpus = @(); $failures.Add('GPU') }
    try {
        if (Confirm-SecureBootUEFI -ErrorAction Stop) { $data.Security.SecureBoot = 'Enabled' }
        else { $data.Security.SecureBoot = 'Disabled' }
    } catch { $failures.Add('SecureBoot') }
    try {
        $osDrive = $env:SystemDrive
        if ($osDrive -notmatch '^[A-Za-z]:$') { throw 'Unknown OS drive' }
        $rows = @(Get-CimInstance -Namespace 'root/CIMV2/Security/MicrosoftVolumeEncryption' -ClassName Win32_EncryptableVolume -Property DriveLetter -Filter "DriveLetter='$osDrive'" -ErrorAction Stop)
        if ($rows.Count -ne 1) { throw 'Unknown OS volume' }
        # Getter methods only; no protector IDs, keys or recovery passwords.
        $conversion = Invoke-CimMethod -InputObject $rows[0] -MethodName GetConversionStatus -Arguments @{ PrecisionFactor = [uint32]0 } -ErrorAction Stop
        $protection = Invoke-CimMethod -InputObject $rows[0] -MethodName GetProtectionStatus -ErrorAction Stop
        if ($conversion.ReturnValue -ne 0 -or $protection.ReturnValue -ne 0) { throw 'Status unavailable' }
        $states = @('FullyDecrypted', 'FullyEncrypted', 'EncryptionInProgress', 'DecryptionInProgress', 'EncryptionPaused', 'DecryptionPaused')
        $volumeState = 'Unknown'; $protectionState = 'Unknown'
        if ($conversion.ConversionStatus -ge 0 -and $conversion.ConversionStatus -lt $states.Count) { $volumeState = $states[$conversion.ConversionStatus] }
        if ($protection.ProtectionStatus -eq 0) { $protectionState = 'Off' }
        elseif ($protection.ProtectionStatus -eq 1) { $protectionState = 'On' }
        $data.Security.OsVolume = [pscustomobject]@{ MountPoint = $osDrive; VolumeStatus = $volumeState; ProtectionStatus = $protectionState; EncryptionPercentage = $conversion.EncryptionPercentage }
    } catch { $failures.Add('BitLockerStatus') }
    $data.QueryFailures = $failures.ToArray()
    $data
}

function Invoke-3070TiIntake {
    param([Parameter(Mandatory = $true)] [string] $ScriptDirectory)
    $inventory = Get-3070TiIntakeInventory
    $report = [pscustomobject][ordered]@{
        SchemaVersion = 1
        CollectedAtUtc = [DateTime]::UtcNow.ToString('o')
        Purpose = 'Public Windows hardware intake only; no unlock attempted'
        Inventory = $inventory
        Assessment = Get-3070TiIntakeAssessment -Inventory $inventory
    }
    $baseDirectory = (Resolve-Path -LiteralPath $ScriptDirectory -ErrorAction Stop).ProviderPath
    if (-not (Test-Path -LiteralPath (Join-Path $baseDirectory 'Collect-3070TiIntake.ps1') -PathType Leaf)) { throw 'Select the script directory.' }
    $relativeDirectory = Join-Path 'output' ([DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff'))
    $outputDirectory = Join-Path $baseDirectory $relativeDirectory
    $null = New-Item -ItemType Directory -Path $outputDirectory -ErrorAction Stop
    $report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $outputDirectory 'inventory.json') -Encoding UTF8 -ErrorAction Stop
    [pscustomobject]@{ Status = $report.Assessment.Status; ReportFile = (Join-Path $relativeDirectory 'inventory.json'); MissingInformation = $report.Assessment.MissingInformation }
}

if ($MyInvocation.InvocationName -ne '.') {
    try {
        # Also permits manual console pasting after changing to this directory.
        $intakeDirectory = $PSScriptRoot
        if ([string]::IsNullOrWhiteSpace($intakeDirectory)) { $intakeDirectory = (Get-Location).ProviderPath }
        Invoke-3070TiIntake -ScriptDirectory $intakeDirectory | ConvertTo-Json -Depth 4
    } catch {
        Write-Output 'Intake could not finish. Check the README and folder write permission. No unlock was attempted.'
        exit 1
    }
}
