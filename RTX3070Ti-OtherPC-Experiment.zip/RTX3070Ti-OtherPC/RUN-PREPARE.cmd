@echo off
cd /d "%~dp0"
echo This launcher allows only this new PowerShell process to run the bundled preparation script.
echo No permanent execution policy, Secure Boot, Defender, or BitLocker settings are changed.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Prepare-RTX30-Experiment.ps1"
echo.
echo Preparation finished or stopped. Read the result above.
pause
