#requires -Version 5.1
param([string]$ReleaseFolder = 'D:\gpu-unlock-guide-20261026\craftingmod-release')
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Prepare-RTX30-Experiment.ps1')
$scriptPath = Join-Path $PSScriptRoot 'Prepare-RTX30-Experiment.ps1'
$tokens = $null; $errors = $null
[void][System.Management.Automation.Language.Parser]::ParseFile($scriptPath, [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | Out-String) }
Write-Output 'PASS Windows PowerShell AST'
$testRoot = Join-Path $PSScriptRoot ('prepare-tests-' + [guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $testRoot)
$cases = @(
    @{Name='rtx30-unlock.zip';Hash='16171785e6c00a1879fa146c192297c834bb1099fcbd6d95e444a24b99ab210b';Files=@('EFI/BOOT/BOOTX64.EFI','RTX-UNLOCK/UNLOCK.md')},
    @{Name='firmware-fetch.zip';Hash='d996f017696fd6211ae0fa62832c49d2eb940899f36ee410ae3b9014d2f6157f';Files=@('firmware-assets.exe')}
)
foreach ($case in $cases) {
    Expand-RTX30VerifiedArchive -Path (Join-Path $ReleaseFolder $case.Name) -ExpectedHash $case.Hash -ExpectedFiles $case.Files -Destination $testRoot
    Write-Output ('PASS actual release hash/layout/extraction: ' + $case.Name)
}
New-RTX30DebugMarker -Root $testRoot
if (-not (Test-Path -LiteralPath (Join-Path $testRoot 'RTX-UNLOCK\DEBUG.ON') -PathType Leaf)) { throw 'Missing DEBUG.ON' }
Write-Output 'PASS empty DEBUG.ON'
$caught = $false
try { Assert-RTX30ArchiveHash -Path (Join-Path $ReleaseFolder 'rtx30-unlock.zip') -ExpectedHash ('0' * 64) }
catch { if ($_.Exception.Message -like 'SHA256 mismatch:*') { $caught=$true } else { throw } }
if (-not $caught) { throw 'Hash mismatch was accepted.' }
Write-Output 'PASS wrong hash rejected'
$badZip = Join-Path $testRoot 'path-traversal-test.zip'
$archive = [IO.Compression.ZipFile]::Open($badZip, [IO.Compression.ZipArchiveMode]::Create)
try { [void]$archive.CreateEntry('../outside.txt') } finally { $archive.Dispose() }
$caught = $false
try { Assert-RTX30ArchiveLayout -Path $badZip -ExpectedFiles @('../outside.txt') }
catch { if ($_.Exception.Message -like 'Unsafe ZIP path:*') { $caught=$true } else { throw } }
if (-not $caught) { throw 'Path traversal was accepted.' }
Write-Output 'PASS path traversal rejected before extraction'
$caught = $false
try { Expand-RTX30VerifiedArchive -Path (Join-Path $ReleaseFolder 'firmware-fetch.zip') -ExpectedHash $cases[1].Hash -ExpectedFiles $cases[1].Files -Destination $testRoot }
catch { if ($_.Exception.Message -like 'Refusing to overwrite:*') { $caught=$true } else { throw } }
if (-not $caught) { throw 'Existing file overwrite was accepted.' }
Write-Output 'PASS existing file overwrite rejected'
Write-Output ('TEST OUTPUT ONLY: ' + $testRoot)
Write-Output 'NO EXE/EFI EXECUTED; NO FIRMWARE GENERATED; NO USB/BOOT/SECURITY CHANGES'
