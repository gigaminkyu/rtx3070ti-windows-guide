#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Assert-RTX30ArchiveHash {
    param([Parameter(Mandatory=$true)][string]$Path, [Parameter(Mandatory=$true)][string]$ExpectedHash)
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    if ($actual -ne $ExpectedHash) { throw "SHA256 mismatch: $Path" }
}

function Assert-RTX30ArchiveLayout {
    param([Parameter(Mandatory=$true)][string]$Path, [Parameter(Mandatory=$true)][string[]]$ExpectedFiles)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
    try {
        $files = @()
        foreach ($entry in $zip.Entries) {
            $name = $entry.FullName.Replace('\', '/')
            if ([string]::IsNullOrWhiteSpace($name) -or $name.StartsWith('/') -or $name.Contains(':') -or
                ($name.Split('/') -contains '..') -or ($name.Split('/') -contains '.') -or $name.Contains('//')) {
                throw "Unsafe ZIP path: $name"
            }
            if ($name.EndsWith('/')) {
                if (-not @($ExpectedFiles | Where-Object { $_.StartsWith($name, [StringComparison]::Ordinal) }).Count) {
                    throw "Unexpected ZIP directory: $name"
                }
                continue
            }
            if ($files -contains $name) { throw "Duplicate ZIP entry: $name" }
            if ($ExpectedFiles -cnotcontains $name) { throw "Unexpected ZIP entry: $name" }
            $files += $name
        }
        if ($files.Count -ne $ExpectedFiles.Count) { throw 'ZIP file count mismatch.' }
        foreach ($expected in $ExpectedFiles) {
            if ($files -cnotcontains $expected) { throw "Missing ZIP entry: $expected" }
        }
    } finally { $zip.Dispose() }
}

function Expand-RTX30VerifiedArchive {
    param([string]$Path, [string]$ExpectedHash, [string[]]$ExpectedFiles, [string]$Destination)
    Assert-RTX30ArchiveHash -Path $Path -ExpectedHash $ExpectedHash
    Assert-RTX30ArchiveLayout -Path $Path -ExpectedFiles $ExpectedFiles
    foreach ($entry in $ExpectedFiles) {
        $target = Join-Path $Destination ($entry.Replace('/', '\'))
        if (Test-Path -LiteralPath $target) { throw "Refusing to overwrite: $target" }
    }
    Expand-Archive -LiteralPath $Path -DestinationPath $Destination
}

function New-RTX30DebugMarker {
    param([Parameter(Mandatory=$true)][string]$Root)
    $directory = Join-Path $Root 'RTX-UNLOCK'
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) { throw 'RTX-UNLOCK directory is missing.' }
    $marker = Join-Path $directory 'DEBUG.ON'
    $file = [System.IO.File]::Open($marker, [System.IO.FileMode]::CreateNew)
    $file.Dispose()
    if ((Get-Item -LiteralPath $marker).Length -ne 0) { throw 'DEBUG.ON must be empty.' }
}

function Invoke-RTX30Prepare {
    if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        $candidate = (Get-Location).Path
        if (-not (Test-Path -LiteralPath (Join-Path $candidate 'Prepare-RTX30-Experiment.ps1') -PathType Leaf)) {
            throw 'For console paste, first open the folder containing Prepare-RTX30-Experiment.ps1.'
        }
        $base = (Get-Item -LiteralPath $candidate).FullName
    } else {
        $base = (Get-Item -LiteralPath $PSScriptRoot).FullName
    }
    # Output only under this ordinary local script folder. Refuse junctions/symlinks.
    $cursor = Get-Item -LiteralPath $base
    while ($null -ne $cursor) {
        if (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'Move this package to an ordinary local folder, not a junction or symlink.'
        }
        $cursor = $cursor.Parent
    }
    if ($base.StartsWith('\\')) { throw 'Use an ordinary local folder, not a network share.' }
    $volume = New-Object System.IO.DriveInfo ([IO.Path]::GetPathRoot($base))
    if ($volume.DriveType -ne [IO.DriveType]::Fixed -or $volume.DriveFormat -ne 'NTFS') {
        throw 'Move this preparation package to a local NTFS disk folder, not the USB/EFI volume.'
    }
    $root = Join-Path $base ('prepared-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
    if (Test-Path -LiteralPath $root) { throw 'Fresh output folder already exists.' }
    [void](New-Item -ItemType Directory -Path $root)
    $downloads = Join-Path $root 'downloads'
    [void](New-Item -ItemType Directory -Path $downloads)
    $specs = @(
        [pscustomobject]@{
            Name='rtx30-unlock.zip'
            Url='https://github.com/craftingmod/rtx30-unlock/releases/download/v0.1.0/rtx30-unlock.zip'
            Sha256='16171785e6c00a1879fa146c192297c834bb1099fcbd6d95e444a24b99ab210b'
            Files=@('EFI/BOOT/BOOTX64.EFI','RTX-UNLOCK/UNLOCK.md')
        },
        [pscustomobject]@{
            Name='firmware-fetch.zip'
            Url='https://github.com/craftingmod/rtx30-unlock/releases/download/v0.1.0/firmware-fetch.zip'
            Sha256='d996f017696fd6211ae0fa62832c49d2eb940899f36ee410ae3b9014d2f6157f'
            Files=@('firmware-assets.exe')
        }
    )
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    foreach ($spec in $specs) {
        $archive = Join-Path $downloads $spec.Name
        Write-Host ('Downloading ' + $spec.Name)
        Invoke-WebRequest -UseBasicParsing -Uri $spec.Url -OutFile $archive
        Expand-RTX30VerifiedArchive -Path $archive -ExpectedHash $spec.Sha256 -ExpectedFiles $spec.Files -Destination $root
    }
    New-RTX30DebugMarker -Root $root
    $manifest = [ordered]@{
        Status='PREPARED_ONLY_NOT_HARDWARE_VALIDATED'
        PreparedAtUtc=[DateTime]::UtcNow.ToString('o')
        Source='https://github.com/craftingmod/rtx30-unlock'
        SourceCommit='5c076dc4ee7fa369639669fa591ac74d8f6dfcd8'
        Release='v0.1.0'
        VerifiedArchives=$specs
        ExeExecuted=$false
        EfiExecuted=$false
        FirmwareGenerated=$false
        UsbWritten=$false
        BootOrSecuritySettingsChanged=$false
        Rtx3070TiHardwareVerified=$false
        DebugMarker='RTX-UNLOCK/DEBUG.ON'
    }
    $manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $root 'PREPARATION.json') -Encoding UTF8
    Write-Host ''
    Write-Host 'Prepared only. No EXE/EFI was executed. This is not a successful unlock.'
    Write-Host ('Output: ' + $root)
    Write-Host 'Read README-EXPERIMENT.md before the next manual step.'
    Write-Host 'To generate firmware manually, use this folder as the working directory:'
    Write-Host ("Set-Location -LiteralPath '" + $root.Replace("'", "''") + "'")
    Write-Host '& .\firmware-assets.exe'
    Write-Host 'Keep RTX-UNLOCK\DEBUG.ON. Copy only EFI and RTX-UNLOCK to a separate prepared USB.'
    return $root
}

if ($MyInvocation.InvocationName -ne '.') {
    try { Invoke-RTX30Prepare | Out-Null }
    catch { Write-Error $_; exit 1 }
}
