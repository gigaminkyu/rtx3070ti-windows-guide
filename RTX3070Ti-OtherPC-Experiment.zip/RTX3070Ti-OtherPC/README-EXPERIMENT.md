# 다른 PC용 RTX 3070 Ti 실험 경로: 준비 도구

이 패키지는 **Windows에서 다운로드·해시 확인·압축 해제만** 한다. EXE/EFI 실행, USB 쓰기, 포맷, 파티션 생성, 부팅 순서·보안 설정 변경은 하지 않는다. 관리자 권한은 필요 없다. 3070 Ti의 GA104를 코드상 후보로 받는 경로이지만, 이 배포본이 다른 사람의 3070 Ti에서 성공했다는 실기 검증은 없다. 제작자의 공개 확인 환경은 Colorful 3090 Ti다.

1. 이 폴더를 친구 PC의 로컬 NTFS 디스크에 풀고 `RUN-PREPARE.cmd`를 실행한다. 새 `prepared-날짜-고유번호` 폴더가 생긴다. 기존 파일은 덮어쓰지 않는다. 다운로드가 막히거나 검증에 실패하면 중단한다.
2. 다음 단계부터는 실제 적용을 원하는 PC에서 사용자가 직접 진행한다. 준비 완료 화면에 출력된 `Set-Location ...`을 Windows PowerShell에 붙여넣고, **그 폴더를 현재 위치로 둔 채** `& .\firmware-assets.exe`를 실행한다. 이 EXE는 NVIDIA/CachyOS의 고정 입력을 받아 펌웨어를 추출·생성한다. 실행 파일 위치가 아니라 현재 폴더가 기준이다. 성공 시 `RTX-UNLOCK\ASSETS`에 펌웨어 5개와 `NVIDIA-LICENSE`가 있어야 한다. 우리는 이 EXE를 실행하거나 신규 펌웨어 생성을 검증하지 않았다.

런처는 동봉된 준비 스크립트 실행에 한해 새 PowerShell 프로세스에 `-ExecutionPolicy Bypass`를 지정한다. 영구 실행 정책을 바꾸지 않으며 외부에서 내려받은 스크립트를 자동 실행하지 않는다. 조직의 그룹 정책 등으로 차단되면 오류에서 멈춘다. 직접 콘솔에 붙여넣는 경우 먼저 이 스크립트가 있는 폴더로 이동해야 한다.

생성 파일: `gsp_ga10x.bin`, `v67-ga102-610.43.03.bin`, `booter_load_ga102.bin`, `gsp_boot_ga102.bin`, `gsp_boot_desc_ga102.bin`, `NVIDIA-LICENSE`. 파일명에 ga102가 들어가더라도 이를 ga104로 바꾸지 않는다. [고정 원본의 해시 목록](https://github.com/craftingmod/rtx30-unlock/blob/5c076dc4ee7fa369639669fa591ac74d8f6dfcd8/tools/firmware/artifacts-610.43.03.json)과 비교한다. 실패·누락·해시 불일치가 있으면 부팅 단계로 넘어가지 않는다.

실험 부팅 준비는 **기존 별도 FAT32 USB**에 준비 폴더의 `EFI`, `RTX-UNLOCK` 두 폴더만 복사하는 방식이다. USB에 기존 같은 이름의 폴더가 있다면 덮어쓰지 말고 다른 빈 매체를 쓴다. Windows가 사용하는 EFI 파티션에는 넣지 않는다. `downloads`, `build`, EXE는 부팅용 USB에 필요 없다. 라이선스와 `RTX-UNLOCK\DEBUG.ON`은 유지한다.

```text
USB 루트
├─ EFI\BOOT\BOOTX64.EFI
└─ RTX-UNLOCK
   ├─ UNLOCK.md
   ├─ DEBUG.ON                 ← 빈 파일, 지우지 말 것
   └─ ASSETS\                 ← 펌웨어 5개 + NVIDIA-LICENSE
```

이 EFI는 실제 하드웨어에 적용하는 프로그램이다. **읽기 전용 진단 EFI가 아니다.** `DEBUG.ON`이 없으면 자동 적용·Windows 부팅 경로가 활성화된다. 위 준비 도구는 이를 막기 위해 빈 `DEBUG.ON`을 만든다. 로그와 수동 확인을 유지한다.

PC를 완전히 종료한 뒤 메인보드의 일회성 부팅 메뉴에서 USB의 **UEFI 항목**을 선택한다. 메뉴 키는 보드마다 다르다. 평소 Windows Boot Manager와 기본 부팅 순서는 유지한다. Secure Boot가 켜져 있으면 이 소스는 거부한다. 이 도구는 이를 끄거나 우회하지 않는다. 장치 암호화를 사용한다면 부팅 환경을 바꾸기 전에 복구키를 확보해야 한다.

자동 검사에 실패하면 그 PC에 적용 가능하다고 판단하지 않는다. 검사가 통과하고 진행을 결정한 경우에만 화면에서 `U`를 한 번 누른다. `Esc` 또는 30초 대기는 취소 후 정지하며, Windows로 자동 복귀하는 동작이 아니다. 작업 중 화면이 꺼질 수 있고 소스는 Windows 복귀에 최대 10분을 안내한다. 오류·정지·복귀 실패 시 물리적으로 전원을 끄고 USB를 빼고, 다음 부팅에서 **Windows Boot Manager**를 선택한다. 불확실한 상태에서 같은 부팅 세션에 재실행하지 않는다.

성공 판정은 정상 Windows 진입, NVIDIA 상태, USB의 `RTX-UNLOCK\RUNnn`·`PROBEnn` 로그, 동일 작업의 전후 성능을 함께 확인해야 한다. 다운로드 성공·녹색 화면·코드 후보 판정만으로 언락 성공이라고 하지 않는다. 대상 GPU가 화면을 담당하는 UEFI 구조와 내부 Windows 부트로더 1개 등 추가 조건이 있어서 모든 PC용 설치기를 의미하지 않는다.

출처: [고정 README](https://github.com/craftingmod/rtx30-unlock/blob/5c076dc4ee7fa369639669fa591ac74d8f6dfcd8/README.md), [펌웨어 EXE의 출력 위치](https://github.com/craftingmod/rtx30-unlock/blob/5c076dc4ee7fa369639669fa591ac74d8f6dfcd8/tools/firmware/exe.ts), [수동 확인·자동 모드·중단 코드](https://github.com/craftingmod/rtx30-unlock/blob/5c076dc4ee7fa369639669fa591ac74d8f6dfcd8/src/gop/app.c), [릴리스 v0.1.0](https://github.com/craftingmod/rtx30-unlock/releases/tag/v0.1.0).
