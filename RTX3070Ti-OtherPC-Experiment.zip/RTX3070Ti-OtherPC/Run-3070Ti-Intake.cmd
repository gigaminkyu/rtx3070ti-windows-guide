@echo off
setlocal
echo Uses Bypass only for this PowerShell process. No permanent policy change.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-3070TiIntake.ps1"
if errorlevel 1 (
  echo.
  echo If script execution was blocked, read README.ko.md for manual console steps.
  echo This launcher does not change permanent execution policy or security settings.
)
echo.
pause
endlocal
