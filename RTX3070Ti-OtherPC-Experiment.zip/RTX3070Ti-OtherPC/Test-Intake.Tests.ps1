$ErrorActionPreference = 'Stop'
$importOutput = @(. (Join-Path $PSScriptRoot 'Collect-3070TiIntake.ps1'))
if ($importOutput.Count) { throw 'Dot-source must not collect inventory.' }
function New-IntakeFixture {
    [pscustomobject]@{
        Board = [pscustomobject]@{ Manufacturer = 'ASUSTeK COMPUTER INC.'; Model = 'TUF GAMING B660M-E D4' }
        Bios = [pscustomobject]@{ Version = '4003' }
        Cpu = [pscustomobject]@{ Name = '12th Gen Intel(R) Core(TM) i7-12700F'; Architecture = 9 }
        Os = [pscustomobject]@{ Caption = 'Microsoft Windows 11 Pro'; Version = '10.0.22000'; Build = '22000'; Architecture = '64-bit' }
        Gpus = @([pscustomobject]@{ Name = 'NVIDIA GeForce RTX 3070 Ti'; VendorId = '10DE'; DeviceId = '2482'; SubsystemId = '50521462'; DriverVersion = '32.0.16.1692' })
        Security = [pscustomobject]@{ SecureBoot = 'Disabled'; OsVolume = [pscustomobject]@{ VolumeStatus = 'FullyDecrypted'; ProtectionStatus = 'Off'; EncryptionPercentage = 0 } }
        QueryFailures = @()
    }
}
$script:checks = 0
function Assert-IntakeStatus {
    param($Data, [string]$Expected, [string]$Case)
    $result = Get-3070TiIntakeAssessment -Inventory $Data
    if ($result.Status -ne $Expected) { throw ($Case + ': got ' + $result.Status + ', expected ' + $Expected) }
    $script:checks++
    $result
}
$f = New-IntakeFixture
$null = Assert-IntakeStatus $f 'REFERENCE_FIELDS_MATCH_NOT_VALIDATED' 'Public reference'
$f = New-IntakeFixture; $f.Board.Model = 'Different motherboard'
$null = Assert-IntakeStatus $f 'RTX3070TI_FOUND_UNVALIDATED' 'Other board does not mean impossible'
$f = New-IntakeFixture; $f.Gpus[0].SubsystemId = '12341458'
$null = Assert-IntakeStatus $f 'RTX3070TI_FOUND_UNVALIDATED' 'Other 3070 Ti vendor'
$f = New-IntakeFixture; $f.Gpus[0].DriverVersion = '32.0.16.2101'
$r = Assert-IntakeStatus $f 'RTX3070TI_FOUND_UNVALIDATED' 'Other driver needs validation'
if ($r.ReferenceDifferences -notcontains 'DRIVER_DIFFERS_FROM_616_92') { throw 'Missing driver difference' }
$f = New-IntakeFixture; $f.Gpus[0].DeviceId = '2702'; $f.Gpus[0].Name = 'NVIDIA GeForce RTX 4080 SUPER'
$f.QueryFailures = @('SecureBoot', 'BitLockerStatus'); $f.Security.SecureBoot = 'Unknown'; $f.Security.OsVolume = $null
$null = Assert-IntakeStatus $f 'NOT_RTX3070TI' 'Known other GPU despite missing privilege'
$f = New-IntakeFixture; $f.Gpus = @()
$null = Assert-IntakeStatus $f 'NOT_RTX3070TI' 'No GPU observed'
$f.QueryFailures = @('GPU')
$null = Assert-IntakeStatus $f 'INCOMPLETE' 'GPU query failure'
$f = New-IntakeFixture; $f.Board.Model = $null
$null = Assert-IntakeStatus $f 'INCOMPLETE' 'Unknown board'
$f = New-IntakeFixture; $f.Security.SecureBoot = 'Unknown'
$null = Assert-IntakeStatus $f 'INCOMPLETE' 'Unknown Secure Boot'
$f = New-IntakeFixture; $f.Gpus[0].DeviceId = $null
$null = Assert-IntakeStatus $f 'INCOMPLETE' 'Missing PCI identity'
$f = New-IntakeFixture; $f.Gpus = @($f.Gpus[0], $f.Gpus[0])
$null = Assert-IntakeStatus $f 'RTX3070TI_FOUND_UNVALIDATED' 'Multiple display adapters'
$f = New-IntakeFixture; $f.Security.SecureBoot = 'Enabled'; $f.Security.OsVolume.VolumeStatus = 'FullyEncrypted'; $f.Security.OsVolume.EncryptionPercentage = 100
$r = Assert-IntakeStatus $f 'REFERENCE_FIELDS_MATCH_NOT_VALIDATED' 'Security does not establish firmware validation'
if (-not ($r.Notes -match 'not fully decrypted')) { throw 'Missing encrypted-volume note' }
$f = New-IntakeFixture; $f.Gpus[0].Name = 'NVIDIA GeForce RTX 3070 Ti Laptop GPU'; $f.Gpus[0].DeviceId = '24A0'
$null = Assert-IntakeStatus $f 'RTX3070TI_FOUND_UNVALIDATED' 'Laptop not declared impossible'
Write-Output ('Fixture checks completed: ' + $script:checks + '; import produced no output.')
